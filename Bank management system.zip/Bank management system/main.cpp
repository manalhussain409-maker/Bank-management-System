
#include <iostream>
#include "database.h"
using namespace std;
 
int main() {
    Database db;
    db.connect();

    int choice;
    do {
        cout << "\n--- Bank Management System ---\n";
        cout << "1. Create Account\n";
        cout << "2. View Accounts\n";
        cout << "3. Deposit\n";
        cout << "4. Withdraw\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if(choice == 1) db.createAccount();
        else if(choice == 2) db.viewAccounts();
        else if(choice == 3) db.deposit();
        else if(choice == 4) db.withdraw();

    } while(choice != 0);

    db.close();
    return 0;
}
