
Bank Management System (C++ + SQLite)

Features:
- Uses SQLite database
- Uses OOP and basic data structure concepts
- Compatible with VS Code

How to Run:
1. Install SQLite
2. Compile:
   g++ main.cpp database.cpp -lsqlite3 -o bank
3. Run:
   ./bank
