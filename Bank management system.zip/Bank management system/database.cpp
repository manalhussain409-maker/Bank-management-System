
#include "database.h"
#include <iostream>
using namespace std;

void Database::connect() {
    sqlite3_open("bank_system.db", &db);
    const char* sql =
        "CREATE TABLE IF NOT EXISTS accounts("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "name TEXT,"
        "balance REAL);";
    sqlite3_exec(db, sql, 0, 0, 0);
} 

void Database::createAccount() {
    string name;
    double balance;
    cout << "Enter Name: ";
    cin >> name;
    cout << "Initial Balance: ";
    cin >> balance;

    string sql = "INSERT INTO accounts(name, balance) VALUES('" +
                 name + "', " + to_string(balance) + ");";
    sqlite3_exec(db, sql.c_str(), 0, 0, 0);
    cout << "Account Created!\n";
}

void Database::viewAccounts() {
    const char* sql = "SELECT * FROM accounts;";
    sqlite3_exec(db, sql,
        [](void*, int argc, char** argv, char**) {
            cout << "ID: " << argv[0]
                 << " Name: " << argv[1]
                 << " Balance: " << argv[2] << endl;
            return 0;
        }, 0, 0);
}

void Database::deposit() {
    int id;
    double amount;
    cout << "Account ID: ";
    cin >> id;
    cout << "Amount: ";
    cin >> amount;

    string sql = "UPDATE accounts SET balance = balance + " +
                 to_string(amount) + " WHERE id=" + to_string(id);
    sqlite3_exec(db, sql.c_str(), 0, 0, 0);
    cout << "Amount Deposited!\n";
}

void Database::withdraw() {
    int id;
    double amount;
    cout << "Account ID: ";
    cin >> id;
    cout << "Amount: ";
    cin >> amount;

    string sql = "UPDATE accounts SET balance = balance - " +
                 to_string(amount) + " WHERE id=" + to_string(id);
    sqlite3_exec(db, sql.c_str(), 0, 0, 0);
    cout << "Amount Withdrawn!\n";
}

void Database::close() {
    sqlite3_close(db);
}
