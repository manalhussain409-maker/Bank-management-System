/* Minimal SQLite3 header wrapper for compilation */
#ifndef SQLITE3_H
#define SQLITE3_H

#ifdef __cplusplus
extern "C" {
#endif
 
/* SQLite type definitions */
typedef struct sqlite3 sqlite3;
typedef struct sqlite3_stmt sqlite3_stmt;

/* Function declarations */
int sqlite3_open(const char *filename, sqlite3 **ppDb);
int sqlite3_close(sqlite3 *db);
int sqlite3_exec(sqlite3 *db, const char *sql, int (*callback)(void*,int,char**,char**), void *arg, char **errmsg);
int sqlite3_prepare_v2(sqlite3 *db, const char *zSql, int nByte, sqlite3_stmt **ppStmt, const char **pzTail);
int sqlite3_step(sqlite3_stmt *pStmt);
int sqlite3_finalize(sqlite3_stmt *pStmt);
int sqlite3_reset(sqlite3_stmt *pStmt);
void sqlite3_free(void *ptr);
int sqlite3_column_int(sqlite3_stmt *stmt, int iCol);
const unsigned char *sqlite3_column_text(sqlite3_stmt *stmt, int iCol);
const void *sqlite3_column_blob(sqlite3_stmt *stmt, int iCol);
int sqlite3_column_bytes(sqlite3_stmt *stmt, int iCol);
const char *sqlite3_errmsg(sqlite3 *db);

/* Return codes */
#define SQLITE_OK           0
#define SQLITE_ERROR        1
#define SQLITE_ROW          100
#define SQLITE_DONE         101

#ifdef __cplusplus
}
#endif

#endif /* SQLITE3_H */
