
#ifndef DATABASE_H
#define DATABASE_H
 
#include <sqlite3.h>
#include <string>
using namespace std;

class Database {
private:
    sqlite3* db;
public:
    void connect();
    void close();
    void createAccount();
    void viewAccounts();
    void deposit();
    void withdraw();
};

#endif
